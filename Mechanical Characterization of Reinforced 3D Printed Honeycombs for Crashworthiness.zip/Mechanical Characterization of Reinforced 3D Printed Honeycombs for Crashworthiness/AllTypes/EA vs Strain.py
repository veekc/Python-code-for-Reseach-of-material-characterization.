import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

# Get the current directory where your Python script is located
current_directory = os.getcwd()

# List all files in the current directory and filter for CSV files
csv_files = [file for file in os.listdir(current_directory) if file.endswith(".csv")]

# Define the gauge length, width, and thickness
gauge_length = 12.4  # mm
width = 12.4  # mm
thickness = 12.4  # mm

# Create lists to store data
absorption_data = []  # List to store energy absorption data
strain_data = []  # List to store strain data
reinforcement_labels = []  # List to store reinforcement type labels
colors = ['red', 'red', 'red','green', 'green', 'green', 'blue', 'blue', 'blue' ]

# Create a figure and axis
fig, ax = plt.subplots(figsize=(8, 8))

for i, csv_file in enumerate(csv_files):
    try:
        # Read the CSV file into a DataFrame, skipping the first two rows (header and units)
        df = pd.read_csv(csv_file, skiprows=2, usecols=[1, 2])

        # Determine the color and reinforced type based on the file index
        reinforced_type = colors[i]

        plt.xticks(fontsize=24)
        plt.yticks(fontsize=24)
        
        load = df.iloc[:, 0]
        displacement = df.iloc[:, 1]

        # Calculate strain and stress
        strain = df.iloc[:, 0] / gauge_length  # Strain = Extension / Gauge Length
        stress = df.iloc[:, 1] / (width * thickness)  # Stress = Load / (Width * Thickness)

        # Calculate energy absorption for each point in the stress-strain curve
        curve = []
        for j in range(len(strain)):
            energy_absorption = np.trapz(displacement[:j + 1], load[:j + 1])/1000
            curve.append(energy_absorption)

        absorption_data.append(curve)
        strain_data.append(strain)
        reinforcement_labels.append(reinforced_type)

        # Plot the energy absorption vs. strain curve with the specified color and label
        plt.plot(strain, curve, color=reinforced_type, label=reinforced_type)

    except Exception:
        # Handle any exceptions if necessary
        pass

# Set plot labels and title
plt.xlabel('Strain (mm/mm)', fontsize=24)
plt.ylabel('Energy Absorption (J)', fontsize=24)

blue_patch = mpatches.Patch(color='blue', label='No Reinforced')
green_patch = mpatches.Patch(color='green', label='Single Reinforced')
red_patch = mpatches.Patch(color='red', label='Double Reinforced')
plt.legend(handles=[blue_patch, green_patch, red_patch], loc='upper left', fontsize=24)

# Show the plot for this dataset
plt.show()





