import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# Get the current directory where your Python script is located
current_directory = os.getcwd()

# List all files in the current directory and filter for CSV files
csv_files = [file for file in os.listdir(current_directory) if file.endswith(".csv")]

# Create an empty list to store dataframes
dataframes = []

plt.figure(figsize=(8, 8))

# Define labels for the legend
legend_labels = ['Double reinforced', 'Single reinforced', 'No reinforced']
legend_colors = ['red', 'green', 'blue']

# Define the gauge length, width, and thickness
gauge_length = 12.4  # mm
width = 12.4  # mm
thickness = 12.4  # mm

for i, csv_file in enumerate(csv_files):
    try:
        # Read the CSV file into a DataFrame, skipping the first two rows (header and units)
        df = pd.read_csv(csv_file, skiprows=2, usecols=[1, 2])

        # Append the DataFrame to the list
        dataframes.append(df)

        # Determine the color based on the file index
        if i<3:
            color1='red'
            print(i)
            
        if i >=3 and i < 6:
            color1='green'
            print(i)
        if i > 5:
            color1='blue'   
            print(i)

        # Calculate strain and stress
        strain = df.iloc[:, 0] / gauge_length  # Strain = Extension / Gauge Length
        stress = df.iloc[:, 1] / (width * thickness)  # Stress = Load / (Width * Thickness)

        # Plot stress-strain data with the specified color and label
        plt.plot(strain, stress, color=color1)
        
        plt.xticks(fontsize=24)
        plt.yticks(fontsize=24)

        # Set plot labels and title
        plt.xlabel('Strain (mm/mm)' ,fontsize=24)
        plt.ylabel('Stress (MPa)' ,fontsize=24)
        #plt.title(f'Stress vs. Strain (Curve)')

        # Enable grid lines
        #plt.grid()

    except Exception as e:
        # Handle any exceptions if necessary
        pass


blue_patch = mpatches.Patch(color='blue', label='No Reinforced')
green_patch = mpatches.Patch(color='green', label='Single Reinforced')
red_patch = mpatches.Patch(color='red', label='Double Reinforced')
plt.legend(handles=[blue_patch, green_patch, red_patch])


    # Add a legend with the specified labels, colors, and font size
plt.legend(handles=[blue_patch, green_patch, red_patch], loc='upper left', fontsize=24)
    

# Show the plot
plt.show()

# Save the plot as an image file
#plt.savefig('stress_strain_plot.png')
