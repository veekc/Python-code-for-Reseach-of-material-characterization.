import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

# Get the current directory where your Python script is located
current_directory = os.getcwd()

# List all files in the current directory and filter for CSV files
csv_files = [file for file in os.listdir(current_directory) if file.endswith(".csv")]

# Create an empty list to store dataframes
dataframes = []

# Define the gauge length, width, and thickness
gauge_length = 12.4  # mm
width = 12.4  # mm
thickness = 12.4  # mm

efficiency_data = {}  # Dictionary to store efficiency data for each reinforced type

plt.figure(figsize=(8, 8))

# Create a figure and axes for the plot
fig, ax1 = plt.subplots(figsize=(6, 6))

# Create an empty list to store results
result_data = []

for i, csv_file in enumerate(csv_files):
    try:
        # Read the CSV file into a DataFrame, skipping the first two rows (header and units)
        df = pd.read_csv(csv_file, skiprows=2, usecols=[1, 2])

        # Append the DataFrame to the list
        dataframes.append(df)

        # Determine the color and reinforced type based on the file index
        if i < 3:
            color1 = 'red'
            reinforced_type = 'Double reinforced'
        elif 3 <= i < 6:
            color1 = 'green'
            reinforced_type = 'No reinforced'
        else:
            color1 = 'blue'
            reinforced_type = 'Single reinforced'

        load = df.iloc[:, 0]
        displacement = df.iloc[:, 1]

        # Calculate strain and stress
        strain = df.iloc[:, 0] / gauge_length  # Strain = Extension / Gauge Length
        stress = df.iloc[:, 1] / (width * thickness)  # Stress = Load / (Width * Thickness)
        max_stress = max(stress)  # Find the maximum stress on the curve
        
        
        # Calculate energy absorption for each point in the stress-strain curve
        curve = []
        for j in range(len(strain)):
            energy_absorption = np.trapz(displacement[:j + 1], load[:j + 1])/1000
            curve.append(energy_absorption)

        # Calculate energy absorption efficiency for each point in the stress-strain curve
        efficiency_curve = []
        for j in range(len(strain)):
            energy_absorption = np.trapz(stress[:j + 1], strain[:j + 1])
            efficiency = (1 / stress[j]) * energy_absorption
            efficiency_curve.append(efficiency)
            EA_efficiency_index = np.argmax(efficiency_curve)
            

        # Find the maximum energy absorption efficiency and its corresponding strain value
        max_efficiency_index = np.argmax(efficiency_curve)
        max_efficiency = efficiency_curve[max_efficiency_index]
        corresponding_strain = strain[EA_efficiency_index]

        # Plot efficiency curves for each reinforced type
        ax1.plot(strain, curve, label=reinforced_type, color=color1)

        # Find the index of the closest matching strain value in the efficiency curve
        closest_index = np.argmin(np.abs(np.array(strain) - corresponding_strain))

        # Mark point on efficiency curve corresponding to max efficiency
        ax1.scatter(strain[closest_index], curve[closest_index], color=color1, marker='o', s=50, label=f'{reinforced_type} Max Efficiency')

        # Add the results to the list
        result_data.append({
            'Reinforced Type': reinforced_type,
            'Max Efficiency': max_efficiency,
            'Corresponding Strain': corresponding_strain
        })

    except Exception as e:
        print(f"Error processing {csv_file}: {str(e)}")


blue_patch = mpatches.Patch(color='blue', label='No Reinforced')
green_patch = mpatches.Patch(color='green', label='Single Reinforced')
red_patch = mpatches.Patch(color='red', label='Double Reinforced')

# Adding legend to the subplot (ax1)
ax1.legend(handles=[blue_patch, green_patch, red_patch], loc='upper left', fontsize=18)

# Set plot labels and title
ax1.set_xlabel('Strain (mm/mm)', fontsize=18)
ax1.set_ylabel('Energy Absorption (J)', fontsize=18)

plt.show()
