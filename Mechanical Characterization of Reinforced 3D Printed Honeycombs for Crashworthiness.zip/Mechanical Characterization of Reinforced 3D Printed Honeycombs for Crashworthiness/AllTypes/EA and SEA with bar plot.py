import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

# Get the current directory where your Python script is located
current_directory = os.getcwd()

# List all files in the current directory and filter for CSV files
csv_files = [file for file in os.listdir(current_directory) if file.endswith(".csv")]

# Create an empty list to store dataframes
dataframes = []

# Create a list to store energy absorption values and reinforced types
energy_absorption_data = []

plt.figure(figsize=(8, 6))

# Define the gauge length, width, and thickness
gauge_length = 12.4  # mm
width = 12.4  # mm
thickness = 12.4  # mm

# Define the masses for each reinforced type
mass_no_reinforced = 1.879/3  # grams
mass_single_reinforced = 2.148/3  # grams
mass_double_reinforced = 2.399/3  # grams

for i, csv_file in enumerate(csv_files):
    try:
        # Read the CSV file into a DataFrame, skipping the first two rows (header and units)
        df = pd.read_csv(csv_file, skiprows=2, usecols=[1, 2])

        # Append the DataFrame to the list
        dataframes.append(df)

        # Determine the color and reinforced type based on the file index
    
        if i >= 6:
            color1 = 'blue'
            reinforced_type = 'No reinforced'
            mass = mass_no_reinforced  # Mass for No Reinforced
        if 3 <= i < 6:
            color1 = 'green'
            reinforced_type = 'Single reinforced'
            mass = mass_single_reinforced  # Mass for Single Reinforced
        if i < 3:
            color1 = 'red'
            reinforced_type = 'Double reinforced'
            mass = mass_double_reinforced  # Mass for Double Reinforced
            
        load = df.iloc[:, 0]
        displacement = df.iloc[:, 1]

        # Calculate strain and stress
        strain = df.iloc[:, 0] / gauge_length  # Strain = Extension / Gauge Length
        stress = df.iloc[:, 1] / (width * thickness)  # Stress = Load / (Width * Thickness)

        # Plot stress-strain data with the specified color and label
        plt.plot(load, displacement, color=color1, label=reinforced_type)

        # Calculate the area under the stress-strain curve (energy absorption)
        energy_absorption = np.trapz(displacement, load)/1000

        # Calculate specific energy absorption (energy absorbed per unit mass)
        specific_energy_absorption = energy_absorption / (mass)  # Convert mass from grams to kilograms

        # Add energy absorption and specific energy absorption values to the list
        energy_absorption_data.append({
            'Reinforced Type': reinforced_type,
            'Energy Absorption (J)': energy_absorption,
            'Specific Energy Absorption (KJ/Kg)': specific_energy_absorption
        })

        # Set plot labels and title
        plt.xlabel('Load')
        plt.ylabel('Displacement')
        plt.title(f'Stress vs. Strain (Curve)')

        # Enable grid lines
       #plt.grid()

        # Show the plot for the current dataset
        # plt.show()

        # Print energy absorption and specific energy absorption values for the current dataset
        print(f'{reinforced_type} EA: {energy_absorption:.2f} J')
        print(f'{reinforced_type} SEA: {specific_energy_absorption:.6f} KJ/Kg')

    except Exception as e:
        # Handle any exceptions if necessary
        pass

# Create a DataFrame with the provided data
data = pd.DataFrame(energy_absorption_data)

# Set up the figure for the bar plot
plt.figure(figsize=(8, 8))

# Define the order of reinforced types
reinforced_types_order = ['No reinforced', 'Single reinforced', 'Double reinforced']

# Calculate the average and standard deviation for each reinforced type
average_values = data.groupby('Reinforced Type').mean().reindex(reinforced_types_order)
std_dev_values = data.groupby('Reinforced Type').std().reindex(reinforced_types_order)

# Plot a bar graph with error bars (standard deviation)
x = np.arange(len(average_values))
bar_width = 0.4

plt.bar(x - bar_width/2, average_values['Energy Absorption (J)'], bar_width, label='Average')
plt.errorbar(x - bar_width/2, average_values['Energy Absorption (J)'], yerr=std_dev_values['Energy Absorption (J)'],
             fmt='o', capsize=12, linewidth=4, label='Standard Deviation', color='black')

plt.xticks(fontsize=18)
plt.yticks(fontsize=18)

# Set the labels and title
plt.xlabel('Reinforced Type', fontsize=24)
plt.ylabel('Energy Absorption (J)', fontsize=24)
#plt.title('Average and Standard Deviation for Reinforced Types', fontsize=24)

# Set the x-axis labels
plt.xticks(x, reinforced_types_order)

# Display the legend
#plt.legend(fontsize=18)

# Save the plot as an image file
#plt.savefig('energy_absorption_plot.png')

# Show the plot
plt.show()






# Create a DataFrame with the provided data
data = pd.DataFrame(energy_absorption_data)

# Set up the figure for the bar plot
plt.figure(figsize=(8, 8))

# Define the order of reinforced types
reinforced_types_order = ['No reinforced', 'Single reinforced', 'Double reinforced']

# Calculate the average and standard deviation for each reinforced type
average_values = data.groupby('Reinforced Type').mean().reindex(reinforced_types_order)
std_dev_values = data.groupby('Reinforced Type').std().reindex(reinforced_types_order)

# Plot a bar graph with error bars (standard deviation)
x = np.arange(len(average_values))
bar_width = 0.4

plt.bar(x - bar_width/2, average_values['Specific Energy Absorption (KJ/Kg)'], bar_width, label='Average')
plt.errorbar(x - bar_width/2, average_values['Specific Energy Absorption (KJ/Kg)'], yerr=std_dev_values['Specific Energy Absorption (KJ/Kg)'],
             fmt='o', capsize=12, linewidth=4, label='Standard Deviation', color='black')

plt.xticks(fontsize=18)
plt.yticks(fontsize=18)

print(std_dev_values)

# Set the labels and title
plt.xlabel('Reinforced Type', fontsize=24)
plt.ylabel('Specific Energy Absorption (KJ/Kg)', fontsize=24)
#plt.title('Average and Standard Deviation for Reinforced Types', fontsize=24)

# Set the x-axis labels
plt.xticks(x, reinforced_types_order)

# Display the legend
#plt.legend(fontsize=18)

# Save the plot as an image file
#plt.savefig('energy_absorption_plot.png')

# Show the plot
plt.show()

# Save the plot as an image file
#plt.savefig('stress_strain_plot.png')

# Create a DataFrame from the energy absorption data
energy_absorption_df = pd.DataFrame(energy_absorption_data)

# Display the energy absorption table
#print("\nEnergy Absorption Table:")
#print(energy_absorption_df)
