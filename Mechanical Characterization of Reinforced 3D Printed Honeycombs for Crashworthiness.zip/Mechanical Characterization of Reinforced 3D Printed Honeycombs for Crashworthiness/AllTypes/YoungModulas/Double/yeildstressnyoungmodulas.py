import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from scipy.optimize import fsolve
from shapely.geometry import LineString

# Constants
gauge_length = 12.4  # mm
thickness = 12.4   # mm
gauge_breadth = 12.4  # mm


# Get the current working directory
current_directory = os.getcwd()

# List all files in the current directory
files = [file for file in os.listdir(current_directory) if file.endswith(".csv")]

# Store Young's Modulus and Yield Stress values for each file
young_modulus_values = []
y2 = []

# Iterate through each CSV file and read it into a DataFrame
for file in files:
    file_path = os.path.join(current_directory, file)
    df = pd.read_csv(file_path, skiprows=[0, 1], usecols=[1, 2])
    
    # Extract displacement and load columns
    displacement_column = df.iloc[:, 0]  # 2nd column
    load_column = df.iloc[:, 1]  # 3rd column
    
    # Calculate engineering stress and strain
    area = thickness * gauge_breadth
    engineering_stress = load_column / area
    engineering_strain = displacement_column / gauge_length
    
    # Calculate true stress and true strain
    true_stress = engineering_stress #engineering_stress * (1 + engineering_strain)
    true_strain = engineering_strain #np.log(1 + engineering_strain)
    
    # Find indices for the specified percentage range
    five_percent_len = int(0.4 * len(true_strain))
    ten_percent_len = int(0.7 * len(true_strain))
    strain_segment = true_strain[five_percent_len:ten_percent_len]
    stress_segment = true_stress[five_percent_len:ten_percent_len]
   
    
    
    # Fit a line to calculate Young's Modulus
    polyfit_coefficients = np.polyfit(strain_segment, stress_segment, 1)
    young_modulus = polyfit_coefficients[0]
    
    # Store Young's Modulus value for this file
    young_modulus_values.append(young_modulus)
    print("Young Modulus:",young_modulus)

    # Find the index of the maximum true stress
    index_max_true_stress = np.argmax(true_stress)

    # Get the corresponding strain at the maximum true stress
    strain_at_max_true_stress = true_strain[index_max_true_stress]

    # Print the maximum true stress and corresponding strain
    print("Maximum True Stress:", np.max(true_stress), "MPa")
    

    # Find yield stress using the average Young's Modulus
    #x1 = strain_segment.iloc[0]+ 0.002 if len(strain_segment) > 0 else None # Set x1 as the first value of strain_segment
    x1 = 0.0085  # Strain at which yield stress is defined
    x2 = (0.05)  # Maximum true strain
    y1 = 0  # Initial stress
    average_modulus = np.mean(young_modulus_values)
    y2 = (average_modulus * (x2 - x1)) + y1
    
    
    # Plot true stress vs true strain
    plt.plot(true_strain, true_stress, label= "Curve")
    plt.plot(strain_segment, np.polyval(polyfit_coefficients, strain_segment), linestyle='--', color='gray')
    
    # Draw a line between (0, 0.002) and (yield_stress, strain_at_max_true_stress)
    plt.plot([x1, x2], [y1, y2], color='k', linestyle='--', label='Line')


    #Create LineString objects for intersection calculation
    curve_1 = LineString(np.column_stack((true_strain, true_stress)))
    line_1 = LineString(np.column_stack(([x1, x2], [y1, y2])))
    intersection = line_1.intersection(curve_1)


    plt.plot(*intersection.xy, 'ro')
    plt.xlabel("True Strain")
    plt.ylabel("True Stress (MPa)")
    plt.legend()
    plt.title("True Stress-Strain Curve with Yield Stress and young modulus")
    plt.grid(False)
   
    plt.show()

    x,y = intersection.xy
    print("yeild strain:" ,x)
    print("yeild stress:" ,y)







