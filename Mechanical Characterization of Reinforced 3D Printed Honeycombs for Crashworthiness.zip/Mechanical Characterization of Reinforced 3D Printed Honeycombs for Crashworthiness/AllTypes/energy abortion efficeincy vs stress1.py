import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

# Get the current directory where your Python script is located
current_directory = os.getcwd()

# List all files in the current directory and filter for CSV files
csv_files = [file for file in os.listdir(current_directory) if file.endswith(".csv")]

# Create an empty list to store dataframes
dataframes = []

# Define the gauge length, width, and thickness
gauge_length = 12.4  # mm
width = 12.4  # mm
thickness = 12.4  # mm

efficiency_data = {}  # Dictionary to store efficiency data for each reinforced type

plt.figure(figsize=(8, 8))

# Create a figure and axes for the plots
fig, ax1 = plt.subplots(figsize=(8, 8))
fig, ax2 = plt.subplots(figsize=(8, 8))

# Create an empty list to store results
result_data = []

for i, csv_file in enumerate(csv_files):
    try:
        # Read the CSV file into a DataFrame, skipping the first two rows (header and units)
        df = pd.read_csv(csv_file, skiprows=2, usecols=[1, 2])

        # Append the DataFrame to the list
        dataframes.append(df)

        # Determine the color and reinforced type based on the file index
        if i < 3:
            color1 = 'red'
            reinforced_type = 'Double reinforced'
        elif 3 <= i < 6:
            color1 = 'green'
            reinforced_type = 'Single reinforced'
        else:
            color1 = 'blue'
            reinforced_type = 'No reinforced'

        load = df.iloc[:, 0]
        displacement = df.iloc[:, 1]

        # Calculate strain and stress
        strain = df.iloc[:, 0] / gauge_length  # Strain = Extension / Gauge Length
        stress = df.iloc[:, 1] / (width * thickness)  # Stress = Load / (Width * Thickness)
        max_stress = max(stress)  # Find the maximum stress on the curve

        plt.xticks(fontsize=24)
        plt.yticks(fontsize=24)

        # Calculate energy absorption efficiency for each point in the stress-strain curve
        efficiency_curve = []
        for j in range(len(strain)):
            energy_absorption = np.trapz(stress[:j + 1], strain[:j + 1])
            efficiency = (1 / stress[j]) * energy_absorption
            efficiency_curve.append(efficiency)

        # Find the maximum energy absorption efficiency and its corresponding strain value
        max_efficiency_index = np.argmax(efficiency_curve)
        max_efficiency = efficiency_curve[max_efficiency_index]
        corresponding_strain = strain[max_efficiency_index]

        # Plot efficiency curves for each reinforced type
        ax1.plot(strain, efficiency_curve, label=reinforced_type, color=color1)

        # Mark point on efficiency curve corresponding to max efficiency
        ax1.scatter(corresponding_strain, max_efficiency, color=color1, marker='o', s=100, label=f'{reinforced_type} Max Efficiency')

        # Plot stress-strain curve
        ax2.plot(strain, stress, label=f'{reinforced_type} energy_absorption-Strain', color=color1)

        # Mark point on stress-strain curve corresponding to max efficiency
        ax2.scatter(corresponding_strain, stress[max_efficiency_index], color=color1, marker='o', s=100, label=f'{reinforced_type} Max Efficiency')

        # Add the results to the list
        result_data.append({
            'Reinforced Type': reinforced_type,
            'Max Efficiency': max_efficiency,
            'Corresponding Strain': corresponding_strain
        })

    except Exception as e:
        print(f"Error processing {csv_file}: {str(e)}")

# Convert the list of results to a DataFrame
result_df = pd.DataFrame(result_data)

# Set labels and title for the first plot
ax1.set_xlabel('Strain', fontsize=24)
ax1.set_ylabel('stress', fontsize=24)
#ax1.legend(fontsize=12)

# Set labels and title for the second plot
ax2.set_xlabel('Strain(mm/mm)', fontsize=24)
ax2.set_ylabel('stress', fontsize=24)
blue_patch = mpatches.Patch(color='blue', label='No Reinforced')
green_patch = mpatches.Patch(color='green', label='Single Reinforced')
red_patch = mpatches.Patch(color='red', label='Double Reinforced')
plt.legend(handles=[blue_patch, green_patch, red_patch], loc='upper left', fontsize=24)


# Show the plots
plt.tight_layout()
plt.show()

# Display the result DataFrame
print(result_df)
