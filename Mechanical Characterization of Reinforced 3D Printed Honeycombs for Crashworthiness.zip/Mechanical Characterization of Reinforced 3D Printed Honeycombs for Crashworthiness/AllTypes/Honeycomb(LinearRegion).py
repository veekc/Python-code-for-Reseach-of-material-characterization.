import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

# Get the current directory where your Python script is located
current_directory = os.getcwd()

# List all files in the current directory and filter for CSV files
csv_files = [file for file in os.listdir(current_directory) if file.endswith(".csv")]

# Create an empty list to store dataframes
dataframes = []

plt.figure(figsize=(8, 8))

# Define labels for the legend
legend_labels = ['Double reinforced', 'Single reinforced', 'No reinforced']

# Define the gauge length, width, and thickness
gauge_length = 12.4  # mm
width = 12.4  # mm
thickness = 12.4  # mm

# Define dictionaries to store Young's Modulus and Yield Point for each curve
young_modulus_dict = {}
yield_point_dict = {}

for i, csv_file in enumerate(csv_files):
    try:
        # Read the CSV file into a DataFrame, skipping the first two rows (header and units)
        df = pd.read_csv(csv_file, skiprows=2, usecols=[1, 2])

        # Calculate the number of rows to keep (2% to 20%)
        num_rows = int(0.2 * len(df))  # 20% of the data
        start_row = int(0.00 * len(df))  # 2% of the data

        # Extract the relevant portion of the data
        df = df.iloc[start_row:num_rows]

        # Append the DataFrame to the list
        dataframes.append(df)

        # Determine the color based on the file index
        if i < 3:
            color1 = 'red'
        if 3 <= i < 7:
            color1 = 'green'
        if i >= 6:
            color1 = 'blue'

        # Calculate engineering strain and stress
        engineering_strain = df.iloc[:, 0] / gauge_length  # Engineering Strain = Extension / Gauge Length
        engineering_stress = df.iloc[:, 1] / (width * thickness)  # Engineering Stress = Load / (Width * Thickness)

        # Calculate true stress and true strain
        true_strain = np.log(1 + engineering_strain)
        true_stress = engineering_stress * (1 + engineering_strain)

        # Find the index of the maximum true stress
        max_stress_index = true_stress.idxmax()

        # Plot true stress vs. true strain up to the point of maximum stress
        plt.plot(true_strain.iloc[:max_stress_index], true_stress.iloc[:max_stress_index], color=color1)

        # Linear fit to find Young's Modulus
        linear_fit = np.polyfit(true_strain, true_stress, 1)
        young_modulus = linear_fit[0]

        # Store Young's Modulus for each curve in the dictionary
        young_modulus_dict[legend_labels[i]] = young_modulus

        # Find the yield point by identifying the stress at the maximum strain
        yield_point = true_stress.max()

        # Store the Yield Point for each curve in the dictionary
        yield_point_dict[legend_labels[i]] = yield_point

    except Exception as e:
        # Handle any exceptions if necessary
        pass

# Display Young's Modulus and Yield Point for each curve
for label in legend_labels:
    print(f"Young's Modulus for {label}: {young_modulus_dict[label]} MPa, Yield Point: {yield_point_dict[label]} MPa")

# Set labels and title
plt.xlabel('Strain (mm/mm)', fontsize=24)
plt.ylabel('Stress (MPa)', fontsize=24)

# Enable grid lines
#plt.grid()

blue_patch = mpatches.Patch(color='blue', label='No Reinforced')
green_patch = mpatches.Patch(color='green', label='Single Reinforced')
red_patch = mpatches.Patch(color='red', label='Double Reinforced')
# Add a legend with the specified labels, colors, and font size
plt.legend(handles=[blue_patch, green_patch, red_patch], loc='upper left', fontsize=18)

# Save the plot as an image file
#image_file_path = os.path.join(current_directory, 'true_stress_strain_plot.png')
#plt.savefig(image_file_path)

# Show the plot
plt.show()
