import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches





def _invert(x, limits):
    return limits[1] - (x - limits[0])

def _scale_data(data, ranges):
    x1, x2 = ranges[0]
    d = data[0]

    if x1 > x2:
        d = _invert(d, (x1, x2))
        x1, x2 = x2, x1

    sdata = [d]

    for d, (y1, y2) in zip(data[1:], ranges[1:]):
        if y1 > y2:
            d = _invert(d, (y1, y2))
            y1, y2 = y2, y1

        sdata.append((d-y1) / (y2-y1) * (x2 - x1) + x1)

    return sdata

def set_rgrids(self, radii, labels=None, angle=None, fmt=None, **kwargs):
    radii = self.convert_xunits(radii)
    radii = np.asarray(radii)
    rmin = radii.min()
    self.set_yticks(radii)
    if labels is not None:
        self.set_yticklabels(labels, fontsize=14)  # Increase font size for ytick labels
    elif fmt is not None:
        self.yaxis.set_major_formatter(FormatStrFormatter(fmt))
    if angle is None:
        angle = self.get_rlabel_position()
    self.set_rlabel_position(angle)
    for t in self.yaxis.get_ticklabels():
        t.update(kwargs)
    return self.yaxis.get_gridlines(), self.yaxis.get_ticklabels()

class ComplexRadar():
    def __init__(self, fig, variables, ranges, n_ordinate_levels=6):
        angles = np.arange(0, 360, 360./len(variables))
        axes = [fig.add_axes([0.1,0.1,0.9,0.9],polar=True, label="axes{}".format(i)) for i in range(len(variables))]
        l, text = axes[0].set_thetagrids(angles, labels=variables, fontsize=20)  # Increase font size to 14
        [txt.set_rotation(angle-90) for txt, angle in zip(text, angles)]
        for ax in axes[1:]:
            ax.patch.set_visible(False)
            ax.grid("off")
            ax.xaxis.set_visible(False)
        for i, ax in enumerate(axes):
            grid = np.linspace(*ranges[i], num=n_ordinate_levels)
            gridlabel = ["{}".format(round(x,2)) for x in grid]
            if ranges[i][0] > ranges[i][1]:
                grid = grid[::-1]
            gridlabel[0] = ""
            set_rgrids(ax, grid, labels=gridlabel, angle=angles[i])
            ax.set_ylim(*ranges[i])
        self.angle = np.deg2rad(np.r_[angles, angles[0]])
        self.ranges = ranges
        self.ax = axes[0]

    def plot(self, data, *args, **kw):
        sdata = _scale_data(data, self.ranges)
        self.ax.plot(self.angle, np.r_[sdata, sdata[0]], *args, **kw)

    def fill(self, data, *args, **kw):
        sdata = _scale_data(data, self.ranges)
        self.ax.fill(self.angle, np.r_[sdata, sdata[0]], *args, **kw)

# Example data
variables = ('              EA(J)', '                        SEA(J/g)', 'MCF(N)           ', 'PCF(N)         ', '           CFE(%)') 
ranges = [(0, 7.01), (0, 8.77),(0, 1090.20),(0, 1642.48), (0.3, 66)]


# Plotting
fig1 = plt.figure(figsize=(6, 6))
radar = ComplexRadar(fig1, variables, ranges)


# Plot and fill for 'Double'
data_double = (7.01, 8.77, 1090.20, 1642.48,66)
radar.plot(data_double, label='Double', color='red')  # Specify color for 'Double'
radar.fill(data_double, alpha=0.1, color='red')

# Plot and fill for 'Single'
data_single = (4.86,6.80,700,1304.51,53)
radar.plot(data_single, label='Single', color='green')  # Specify color for 'Single'
radar.fill(data_single, alpha=0.1, color='green')

# Plot and fill for 'No'
data_no = (2.75,4.38,345.47,668.33,51)
radar.plot(data_no, label='No', color='blue')  # Specify color for 'No'
radar.fill(data_no, alpha=0.1, color='blue')



labels = ('Double', 'Single', 'No')
blue_patch = mpatches.Patch(color='blue', label='No')
green_patch = mpatches.Patch(color='green', label='Single')
red_patch = mpatches.Patch(color='red', label='Double')

plt.legend(handles=[red_patch, green_patch, blue_patch], loc='upper left', bbox_to_anchor=(1.2, 1.1), fontsize=16)

plt.show()
